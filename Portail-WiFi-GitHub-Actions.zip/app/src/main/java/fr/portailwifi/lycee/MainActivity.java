package fr.portailwifi.lycee;

import android.app.Activity;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;
import org.json.JSONException;

public class MainActivity extends Activity {
    private static final String START_URL =
        "https://captiveportal.aerocampus.com/guest/aero-guest-register.php?cmd=login&mac=0c%3A8b%3Afd%3A98%3Af4%3A40&essid=AERO-GUESTS&ip=172.16.42.10&apname=AP_2153_AIRBUS_ETG1&apmac=48%3A00%3A20%3Acd%3Ab2%3A66&vcname=IAP-AEROCAMPUS-1&switchip=captiveportal-login.aerocampus.com&url=http%3A%2F%2Fconnectivitycheck.gstatic.com%2Fgenerate_204&nas-id=IAP-AEROCAMPUS-1&_browser=1";
    private static final String PORTAL_HOST = "captiveportal.aerocampus.com";
    private WebView webView;
    private ProgressBar progress;
    private TextView status;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        Button back = new Button(this);
        back.setText("Retour");
        back.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
        });

        Button reload = new Button(this);
        reload.setText("Actualiser");
        reload.setOnClickListener(v -> webView.reload());

        Button home = new Button(this);
        home.setText("Portail");
        home.setOnClickListener(v -> webView.loadUrl(START_URL));

        bar.addView(back, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(reload, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(home, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        status = new TextView(this);
        status.setText("Connexion au portail Wi-Fi…");
        status.setPadding(12, 4, 12, 4);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSaveFormData(true);

        webView.addJavascriptInterface(new FormStore(), "PortalStore");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress == 100 ? View.GONE : View.VISIBLE);
            }
            @Override public void onReceivedTitle(WebView view, String title) {
                status.setText(title == null ? "Portail Wi-Fi" : title);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                status.setText("Chargement du portail…");
                progress.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (PORTAL_HOST.equalsIgnoreCase(uri.getHost())) {
                    status.setText("Portail Wi-Fi");
                    injectFieldPersistence();
                } else {
                    status.setText("Page externe");
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if ("https".equalsIgnoreCase(uri.getScheme()) &&
                    PORTAL_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                // Les redirections HTTP de contrôle de connectivité peuvent être nécessaires
                // au portail captif ; elles restent dans la WebView, sans désactiver TLS.
                if ("http".equalsIgnoreCase(uri.getScheme()) &&
                    (uri.getHost() != null &&
                     (uri.getHost().equalsIgnoreCase("connectivitycheck.gstatic.com") ||
                      uri.getHost().endsWith(".aerocampus.com")))) {
                    return false;
                }
                if ("https".equalsIgnoreCase(uri.getScheme()) ||
                    "http".equalsIgnoreCase(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) {}
                    return true;
                }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return shouldOverrideUrlLoading(view, request.getUrl().toString());
            }

            // Important : on ne contourne jamais les erreurs de certificat.
            @Override
            public void onReceivedSslError(WebView view,
                    android.webkit.SslErrorHandler handler,
                    android.net.http.SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this,
                    "Certificat HTTPS invalide : connexion bloquée pour ta sécurité.",
                    Toast.LENGTH_LONG).show();
            }
        });

        page.addView(bar);
        page.addView(progress, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 5));
        page.addView(status);
        page.addView(webView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(page);

        if (state == null) webView.loadUrl(START_URL);
        else webView.restoreState(state);
    }

    private void injectFieldPersistence() {
        String js =
            "(function(){try{" +
            "var key='portal_fields_v1';" +
            "var saved=JSON.parse(PortalStore.load()||'{}');" +
            "function eligible(e){" +
            " if(!e || !e.name) return false;" +
            " var t=(e.type||'').toLowerCase();" +
            " return ['text','email','tel','number','search','url'].indexOf(t)>=0 ||" +
            " e.tagName==='TEXTAREA' || e.tagName==='SELECT';" +
            "}" +
            "var els=document.querySelectorAll('input,textarea,select');" +
            "for(var i=0;i<els.length;i++){" +
            " var e=els[i]; if(!eligible(e)) continue;" +
            " var k=e.name; if(Object.prototype.hasOwnProperty.call(saved,k)) e.value=saved[k];" +
            "}" +
            "function save(){" +
            " var out={}; var a=document.querySelectorAll('input,textarea,select');" +
            " for(var j=0;j<a.length;j++){var x=a[j]; if(eligible(x)) out[x.name]=x.value;}" +
            " PortalStore.save(JSON.stringify(out));" +
            "}" +
            "document.addEventListener('input',save,true);" +
            "document.addEventListener('change',save,true);" +
            "}catch(ex){}})();";
        webView.evaluateJavascript(js, null);
    }

    private class FormStore {
        @JavascriptInterface
        public String load() {
            SharedPreferences p = getSharedPreferences("portal_fields", MODE_PRIVATE);
            return p.getString("values", "{}");
        }
        @JavascriptInterface
        public void save(String json) {
            try {
                JSONObject obj = new JSONObject(json);
                JSONObject safe = new JSONObject();
                java.util.Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    // Ne jamais stocker les champs portant un nom évoquant un secret.
                    String lower = key.toLowerCase();
                    if (lower.contains("pass") || lower.contains("pwd") ||
                        lower.contains("token") || lower.contains("secret")) continue;
                    Object value = obj.opt(key);
                    if (value instanceof String) safe.put(key, value);
                }
                getSharedPreferences("portal_fields", MODE_PRIVATE)
                    .edit().putString("values", safe.toString()).apply();
            } catch (JSONException ignored) {}
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PortalStore");
            webView.destroy();
        }
        super.onDestroy();
    }
}
