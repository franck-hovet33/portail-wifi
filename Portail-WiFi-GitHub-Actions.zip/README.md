# Portail Wi-Fi — APK Android 5 compilé par GitHub Actions

Ce dépôt contient une application Android légère qui ouvre le portail captif AeroCampus dans une WebView.

## Compatibilité
- Android 5.0 (API 21) minimum.
- `compileSdkVersion 28`, `targetSdkVersion 28`.
- Java 8, Android Gradle Plugin 3.5.4, Gradle 6.7.1.

## Compilation depuis GitHub.com

1. Crée un dépôt GitHub (par exemple `portail-wifi`).
2. Dans le dépôt, clique sur **Add file > Upload files**.
3. Décompresse l'archive téléchargée et dépose **le contenu du dossier** dans le dépôt (y compris le dossier caché `.github`).
4. Clique sur **Commit changes** sur la branche `main`.
5. Ouvre l'onglet **Actions**. Le workflow **Build Android APK** se lance automatiquement.
6. Quand le workflow est terminé avec une coche verte, ouvre son exécution.
7. Dans la section **Artifacts**, télécharge `Portail-WiFi-Android5-debug`.
8. Décompresse l'archive téléchargée : elle contient `app-debug.apk`.

Tu peux aussi relancer une compilation manuellement depuis **Actions > Build Android APK > Run workflow**.

## Mémorisation des champs
L'application mémorise localement les champs nommés de type texte, e-mail, téléphone,
nombre, recherche, URL, listes et zones de texte. Les champs de type mot de passe
et les champs dont le nom contient `pass`, `pwd`, `token` ou `secret` sont exclus.
Les données restent dans les préférences privées de l'application. Elles sont effacées
si l'application est désinstallée ou si ses données sont effacées.

## Sécurité et limites
- L'application n'accepte pas les certificats HTTPS invalides : elle annule l'erreur TLS.
- Ne saisis pas de mot de passe si Android signale une erreur de certificat.
- Le mécanisme de mémorisation est limité à l'hôte exact `captiveportal.aerocampus.com`.
- L'URL fournie inclut une adresse MAC et une IP qui peuvent changer. Si le portail fournit
  une nouvelle URL lors d'une autre connexion, il faudra mettre à jour `START_URL` dans
  `MainActivity.java` ou utiliser une adresse de portail stable fournie par l'établissement.
- Le fichier généré par ce workflow est un APK **debug**. Pour une diffusion durable,
  il faudra configurer une signature release privée et conserver la clé en lieu sûr.

## Dépannage
Si le workflow échoue, ouvre l'exécution dans **Actions**, développe l'étape rouge et
copie le message d'erreur pour obtenir de l'aide.
