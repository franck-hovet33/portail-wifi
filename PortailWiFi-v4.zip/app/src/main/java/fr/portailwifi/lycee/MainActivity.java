package fr.portailwifi.lycee;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String START_URL =
        "https://captiveportal.aerocampus.com/guest/aero-guest-register.php?cmd=login&mac=0c%3A8b%3Afd%3A98%3Af4%3A40&essid=AERO-GUESTS&ip=172.16.42.10&apname=AP_2153_AIRBUS_ETG1&apmac=48%3A00%3A20%3Acd%3Ab2%3A66&vcname=IAP-AEROCAMPUS-1&switchip=captiveportal-login.aerocampus.com&url=http%3A%2F%2Fconnectivitycheck.gstatic.com%2Fgenerate_204&nas-id=IAP-AEROCAMPUS-1&_browser=1";

    private static final String SETTINGS_NAME = "portal_settings";
    private static final String URL_KEY = "portal_url";
    private static final String URL_NAME_KEY = "portal_url_name";
    private static final String HISTORY_KEY = "portal_history";

    private WebView webView;
    private ProgressBar progress;
    private TextView status;

    private SharedPreferences settingsPrefs() {
        return getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE);
    }

    private String getPortalUrl() {
        return settingsPrefs().getString(URL_KEY, START_URL);
    }

    private String getPortalName() {
        return settingsPrefs().getString(URL_NAME_KEY, "Portail AeroCampus");
    }

    private void setCurrentPortal(String name, String url) {
        settingsPrefs().edit()
            .putString(URL_KEY, url)
            .putString(URL_NAME_KEY, name)
            .apply();
    }

    private void openPortal() {
        if (webView != null) {
            status.setText("Ouverture du portail…");
            webView.loadUrl(getPortalUrl());
        }
    }

    private boolean isValidWebUrl(String value) {
        try {
            Uri uri = Uri.parse(value.trim());
            String scheme = uri.getScheme();
            return uri.getHost() != null &&
                ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) &&
                uri.getUserInfo() == null;
        } catch (Exception e) {
            return false;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    /*
     * Appui long sur « Portail » :
     * le formulaire permet de nommer une adresse, et son bouton ☰
     * ouvre l'historique sans ajouter de bouton permanent à l'écran principal.
     */
    private void showSavePortalDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        form.setPadding(pad, dp(8), pad, 0);

        LinearLayout historyRow = new LinearLayout(this);
        historyRow.setOrientation(LinearLayout.HORIZONTAL);
        historyRow.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);

        Button historyButton = new Button(this);
        historyButton.setText("☰ Historique");
        historyButton.setContentDescription("Afficher l'historique des portails");
        historyRow.addView(historyButton, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        form.addView(historyRow);

        TextView nameLabel = new TextView(this);
        nameLabel.setText("Nom à afficher");
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Ex. Wi-Fi du lycée");
        nameInput.setText(getPortalName());

        TextView urlLabel = new TextView(this);
        urlLabel.setText("Adresse du portail");
        LinearLayout.LayoutParams secondLabelParams =
            new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        secondLabelParams.topMargin = dp(10);

        EditText urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setHint("https://...");
        urlInput.setText(getPortalUrl());
        urlInput.setSelection(urlInput.getText().length());

        form.addView(nameLabel);
        form.addView(nameInput);
        form.addView(urlLabel, secondLabelParams);
        form.addView(urlInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Ajouter ou modifier un portail")
            .setView(form)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", null)
            .create();

        historyButton.setOnClickListener(v -> showHistoryDialog(nameInput, urlInput));

        dialog.setOnShowListener(ignored -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            saveButton.setOnClickListener(v -> {
                savePortalEntry(nameInput, urlInput, true, dialog);
            });
        });
        dialog.show();
    }

    private void savePortalEntry(EditText nameInput, EditText urlInput,
                                 boolean openAfterSave, AlertDialog dialog) {
        String name = nameInput.getText().toString().trim();
        String url = urlInput.getText().toString().trim();

        if (name.length() == 0) {
            nameInput.setError("Donne un nom à ce portail");
            return;
        }
        if (!isValidWebUrl(url)) {
            urlInput.setError("Adresse invalide. Utilise http:// ou https://");
            return;
        }

        setCurrentPortal(name, url);
        addHistoryEntry(name, url);

        Toast.makeText(this, "Portail enregistré dans l'historique",
            Toast.LENGTH_SHORT).show();
        dialog.dismiss();

        if (openAfterSave) {
            openPortal();
        }
    }

    private JSONArray readHistory() {
        String raw = getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE)
            .getString(HISTORY_KEY, "[]");
        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private void addHistoryEntry(String name, String url) {
        JSONArray oldHistory = readHistory();
        JSONArray updated = new JSONArray();

        JSONObject newEntry = new JSONObject();
        try {
            newEntry.put("name", name);
            newEntry.put("url", url);
            newEntry.put("date", System.currentTimeMillis());
            updated.put(newEntry);

            for (int i = 0; i < oldHistory.length(); i++) {
                JSONObject old = oldHistory.optJSONObject(i);
                if (old != null) updated.put(old);
            }

            getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE)
                .edit().putString(HISTORY_KEY, updated.toString()).apply();
        } catch (JSONException ignored) {
            // A malformed entry is simply not added.
        }
    }

    /*
     * L'historique est accessible uniquement depuis le formulaire qui s'ouvre
     * avec un appui long sur « Portail ». Choisir une entrée remplit les champs
     * du formulaire : l'utilisateur peut ensuite modifier ou enregistrer.
     */
    private void showHistoryDialog(EditText nameInput, EditText urlInput) {
        JSONArray history = readHistory();
        if (history.length() == 0) {
            new AlertDialog.Builder(this)
                .setTitle("Historique des portails")
                .setMessage("Aucun lien enregistré pour le moment.")
                .setPositiveButton("Retour", null)
                .show();
            return;
        }

        final JSONArray entries = history;
        String[] labels = new String[entries.length()];
        SimpleDateFormat formatter =
            new SimpleDateFormat("dd/MM/yyyy à HH:mm", Locale.FRANCE);

        for (int i = 0; i < entries.length(); i++) {
            JSONObject item = entries.optJSONObject(i);
            String name = item == null ? "Portail sans nom" :
                item.optString("name", "Portail sans nom");
            long date = item == null ? 0L : item.optLong("date", 0L);
            String dateText = date > 0
                ? formatter.format(new Date(date))
                : "Date inconnue";
            String url = item == null ? "" : item.optString("url", "");
            labels[i] = name + "\n" + url + "\n" + dateText;
        }

        AlertDialog historyDialog = new AlertDialog.Builder(this)
            .setTitle("Historique des portails")
            .setItems(labels, (d, which) -> {
                JSONObject item = entries.optJSONObject(which);
                if (item == null) return;

                String name = item.optString("name", "Portail");
                String url = item.optString("url", "");
                if (!isValidWebUrl(url)) {
                    Toast.makeText(this, "Cette adresse enregistrée n'est pas valide.",
                        Toast.LENGTH_LONG).show();
                    return;
                }

                nameInput.setText(name);
                urlInput.setText(url);
                urlInput.setSelection(urlInput.getText().length());
            })
            .setNeutralButton("Effacer l'historique", (d, which) -> confirmClearHistory())
            .setNegativeButton("Retour", null)
            .create();
        historyDialog.show();
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
            .setTitle("Effacer l'historique ?")
            .setMessage("Les liens enregistrés et leurs dates seront supprimés. Le portail actuellement sélectionné restera enregistré.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Effacer", (d, which) -> {
                settingsPrefs().edit().remove(HISTORY_KEY).apply();
                Toast.makeText(this, "Historique effacé", Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    private boolean isPortalHost(String host) {
        if (host == null) return false;
        Uri configured = Uri.parse(getPortalUrl());
        String configuredHost = configured.getHost();
        String lower = host.toLowerCase(Locale.US);

        if (configuredHost != null &&
            (lower.equals(configuredHost.toLowerCase(Locale.US)) ||
             lower.endsWith("." + configuredHost.toLowerCase(Locale.US)))) {
            return true;
        }
        return lower.equals("aerocampus.com") || lower.endsWith(".aerocampus.com");
    }

    private boolean shouldKeepInApp(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (host == null || scheme == null) return false;
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
        return isPortalHost(host) || host.equalsIgnoreCase("connectivitycheck.gstatic.com");
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        Button back = new Button(this);
        back.setText("Retour");
        back.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
            else Toast.makeText(this, "Aucune page précédente", Toast.LENGTH_SHORT).show();
        });

        Button reload = new Button(this);
        reload.setText("Actualiser");
        reload.setOnClickListener(v -> webView.reload());

        Button home = new Button(this);
        home.setText("Portail");
        home.setOnClickListener(v -> openPortal());
        home.setOnLongClickListener(v -> {
            showSavePortalDialog();
            return true;
        });

        bar.addView(back, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(reload, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(home, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        status = new TextView(this);
        status.setText("Connexion au portail Wi-Fi…");
        status.setPadding(dp(12), dp(4), dp(12), dp(4));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSaveFormData(true);

        webView.addJavascriptInterface(new FormStore(), "PortalStore");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress == 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (title != null && title.length() > 0) status.setText(title);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                status.setText("Chargement du portail…");
                progress.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (isPortalHost(uri.getHost())) {
                    status.setText("Portail Wi-Fi");
                    injectFieldPersistence();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (shouldKeepInApp(uri)) return false;

                if ("https".equalsIgnoreCase(uri.getScheme()) ||
                    "http".equalsIgnoreCase(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this,
                            "Aucune application ne peut ouvrir ce lien.",
                            Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return shouldOverrideUrlLoading(view, request.getUrl().toString());
            }

            @Override
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                if (view.getUrl() != null && view.getUrl().equals(failingUrl)) {
                    progress.setVisibility(View.GONE);
                    if (errorCode == ERROR_HOST_LOOKUP) {
                        status.setText("Adresse introuvable — connecte-toi au Wi-Fi AERO-GUESTS.");
                        Toast.makeText(MainActivity.this,
                            "Impossible de trouver le serveur. Connecte-toi d'abord au Wi-Fi du lycée, puis réessaie.",
                            Toast.LENGTH_LONG).show();
                    } else {
                        status.setText("Impossible de charger la page web.");
                    }
                }
            }

            // Les certificats HTTPS invalides restent refusés.
            @Override
            public void onReceivedSslError(WebView view,
                    android.webkit.SslErrorHandler handler,
                    android.net.http.SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this,
                    "Certificat HTTPS invalide : connexion bloquée pour ta sécurité.",
                    Toast.LENGTH_LONG).show();
            }
        });

        page.addView(bar);
        page.addView(progress, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(5)));
        page.addView(status);
        page.addView(webView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(page);

        if (state == null) openPortal();
        else webView.restoreState(state);
    }

    /*
     * Mémorisation locale des champs de formulaire non sensibles :
     * aucun champ de type password n'est enregistré.
     */
    private void injectFieldPersistence() {
        String js =
            "(function(){try{" +
            "var saved=JSON.parse(PortalStore.load()||'{}');" +
            "function eligible(e){" +
            " if(!e || !e.name) return false;" +
            " var t=(e.type||'').toLowerCase();" +
            " return ['text','email','tel','number','search','url'].indexOf(t)>=0 ||" +
            " e.tagName==='TEXTAREA' || e.tagName==='SELECT';" +
            "}" +
            "var els=document.querySelectorAll('input,textarea,select');" +
            "for(var i=0;i<els.length;i++){" +
            " var e=els[i]; if(!eligible(e)) continue;" +
            " var k=e.name; if(Object.prototype.hasOwnProperty.call(saved,k)) e.value=saved[k];" +
            "}" +
            "function save(){" +
            " var out={}; var a=document.querySelectorAll('input,textarea,select');" +
            " for(var j=0;j<a.length;j++){var x=a[j]; if(eligible(x)) out[x.name]=x.value;}" +
            " PortalStore.save(JSON.stringify(out));" +
            "}" +
            "document.addEventListener('input',save,true);" +
            "document.addEventListener('change',save,true);" +
            "}catch(ex){}})();";
        webView.evaluateJavascript(js, null);
    }

    private class FormStore {
        @JavascriptInterface
        public String load() {
            SharedPreferences p = getSharedPreferences("portal_fields", MODE_PRIVATE);
            return p.getString("values", "{}");
        }

        @JavascriptInterface
        public void save(String json) {
            try {
                JSONObject obj = new JSONObject(json);
                JSONObject safe = new JSONObject();
                java.util.Iterator<String> keys = obj.keys();

                while (keys.hasNext()) {
                    String key = keys.next();
                    String lower = key.toLowerCase(Locale.US);
                    if (lower.contains("pass") || lower.contains("pwd") ||
                        lower.contains("token") || lower.contains("secret")) {
                        continue;
                    }
                    Object value = obj.opt(key);
                    if (value instanceof String) safe.put(key, value);
                }

                getSharedPreferences("portal_fields", MODE_PRIVATE)
                    .edit().putString("values", safe.toString()).apply();
            } catch (JSONException ignored) {
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PortalStore");
            webView.destroy();
        }
        super.onDestroy();
    }
}
