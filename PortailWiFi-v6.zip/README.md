# Portail Wi-Fi — version 6.0 (Android 5+)

Application Android légère pour ouvrir le portail captif du lycée dans une WebView.

## Fonctionnalités de la version 6.0

- Appui long sur **Actualiser** : enregistre la page affichée dans l'historique et approuve son domaine.
- Appui court sur **Portail** : ouvre le portail actuellement sélectionné.
- Appui long sur **Portail** : ouvre un formulaire avec un nom et une adresse URL.
- **Enregistrer** : mémorise le nom et l'adresse puis ouvre le portail.
- Le bouton **☰ Historique** apparaît uniquement dans la fenêtre qui s'ouvre avec l'appui long sur **Portail**.
- Toucher une entrée de l'historique recopie son nom et son URL dans le formulaire, sans l'ouvrir immédiatement.
- Le formulaire ne contient plus que deux boutons : **Annuler** et **Enregistrer**. L'enregistrement sélectionne et ouvre le portail.
- L'historique conserve les liens enregistrés avec leur nom, leur URL et leur date.
- Une petite icône Wi-Fi vectorielle est utilisée comme icône de l'application : elle est native Android, très légère et ne nécessite aucune image externe.
- Les champs de formulaire non sensibles sont mémorisés localement. Les mots de passe ne sont pas enregistrés.

## Compatibilité

- Android 5.0 (API 21) minimum.
- `compileSdkVersion 28`, `targetSdkVersion 28`.
- Java 8 pour le projet Android (Java 17 est utilisé uniquement pour les outils SDK).
- Android Gradle Plugin 3.5.4 et Gradle 5.6.4.

## Compiler avec GitHub.com

1. Dans ton dépôt GitHub, remplace l'ancien fichier ZIP par cette nouvelle archive, à la racine.
2. Garde le workflow sous `.github/workflows/build.yml`. Le fichier `build.yml` de cette archive est également fourni pour référence.
3. Le dépôt doit contenir un seul ZIP du projet à la racine pour éviter toute ambiguïté.
4. Après avoir validé les changements, ouvre **Actions**.
5. Ouvre l'exécution « Compilation APK Portail Wi-Fi ».
6. Une fois terminée, télécharge l'artefact `Portail-WiFi-APK`.
7. Décompresse l'artefact : il contient `app-debug.apk`.

Si le workflow est déjà présent dans le dépôt, le remplacement du ZIP déclenche une nouvelle compilation automatiquement.

## Sécurité

- Les erreurs de certificat HTTPS du portail sélectionné peuvent être acceptées après confirmation explicite ; les autres hôtes restent bloqués.
- Les champs de mot de passe ne sont pas enregistrés.
- Les URLs doivent commencer par `http://` ou `https://`.
- Les liens de l'historique sont stockés dans les préférences privées de l'application.
- L'URL AeroCampus initiale contient une adresse MAC et une IP susceptibles de changer selon la session Wi-Fi. L'appui long sur **Portail** permet d'ajouter une URL mise à jour.
- La suppression des données de l'application ou sa désinstallation efface l'historique et les champs mémorisés.

## Remarque sur la mise à jour

L'APK généré est une version debug. Pour installer une version compilée par la même configuration de signature, Android peut permettre une mise à jour directe. Si Android indique une incompatibilité de signature, désinstalle l'ancienne version avant d'installer la nouvelle ; cela efface les données locales de cette ancienne installation.


## Certificats HTTPS (version 6.0)

| Situation | Comportement |
|---|---|
| `captiveportal.aerocampus.com` | Certificat invalide accepté automatiquement, sans fenêtre |
| Domaine enregistré via appui long sur **Portail** → **Enregistrer** | Approuvé automatiquement, de façon permanente |
| Page validée par appui long sur **Actualiser** | Ajoutée à l'historique, domaine approuvé de façon permanente |
| `captiveportal-login.aerocampus.com` et tout autre domaine | Fenêtre de confirmation (valable pour la session) |

L'approbation concerne le nom de domaine exact, sans ses sous-domaines.

**Avertissement :** accepter un certificat invalide réduit la protection HTTPS : une personne
contrôlant le réseau peut potentiellement intercepter les données. N'approuve que des domaines de
confiance et ne saisis pas de mot de passe sensible sur un portail non vérifié.

## Liste « Ouvrir avec » d'Android

L'application déclare des filtres de liens HTTP et HTTPS pour `captiveportal.aerocampus.com` et
`captiveportal-login.aerocampus.com`. Android peut alors la proposer à la connexion au Wi-Fi.
Android garde la main sur cette liste. Si l'application n'apparaît pas, désinstalle l'ancienne
version avant d'installer la V6.
