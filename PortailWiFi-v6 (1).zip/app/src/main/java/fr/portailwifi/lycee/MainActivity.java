package fr.portailwifi.lycee;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String START_URL =
        "https://captiveportal.aerocampus.com/guest/aero-guest-register.php?cmd=login&mac=0c%3A8b%3Afd%3A98%3Af4%3A40&essid=AERO-GUESTS&ip=172.16.42.10&apname=AP_2153_AIRBUS_ETG1&apmac=48%3A00%3A20%3Acd%3Ab2%3A66&vcname=IAP-AEROCAMPUS-1&switchip=captiveportal-login.aerocampus.com&url=http%3A%2F%2Fconnectivitycheck.gstatic.com%2Fgenerate_204&nas-id=IAP-AEROCAMPUS-1&_browser=1";

    private static final String SETTINGS_NAME = "portal_settings";
    private static final String URL_KEY = "portal_url";
    private static final String URL_NAME_KEY = "portal_url_name";
    private static final String HISTORY_KEY = "portal_history";

    private static final String TRUSTED_HOSTS_KEY = "trusted_hosts";
    private static final int HISTORY_MAX = 50;
    // Domaine du portail du lycée : certificat invalide accepté automatiquement, sans fenêtre.
    private static final String AUTO_TRUSTED_HOST = "captiveportal.aerocampus.com";

    private WebView webView;
    private ProgressBar progress;
    private TextView status;
    // Autorisations accordées via la fenêtre de confirmation : valables pour la session seulement.
    private final Set<String> sessionTrustedCertificateHosts = new HashSet<String>();

    /* ---------- Domaines approuvés (conservés après fermeture de l'application) ---------- */

    private Set<String> readTrustedHosts() {
        Set<String> hosts = new HashSet<String>();
        String raw = settingsPrefs().getString(TRUSTED_HOSTS_KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String h = arr.optString(i, "");
                if (h.length() > 0) hosts.add(h.toLowerCase(Locale.US));
            }
        } catch (JSONException ignored) { }
        return hosts;
    }

    private void trustHost(String host) {
        if (host == null || host.length() == 0) return;
        Set<String> hosts = readTrustedHosts();
        hosts.add(host.toLowerCase(Locale.US));
        JSONArray arr = new JSONArray();
        for (String h : hosts) arr.put(h);
        settingsPrefs().edit().putString(TRUSTED_HOSTS_KEY, arr.toString()).apply();
    }

    private void trustHostOfUrl(String url) {
        try {
            trustHost(Uri.parse(url.trim()).getHost());
        } catch (Exception ignored) { }
    }

    private boolean isTrustedHost(String host) {
        if (host == null) return false;
        String lower = host.toLowerCase(Locale.US);
        // Nom de domaine exact uniquement, sous-domaines non inclus.
        return lower.equals(AUTO_TRUSTED_HOST) || readTrustedHosts().contains(lower);
    }

    private SharedPreferences settingsPrefs() {
        return getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE);
    }

    private String getPortalUrl() {
        return settingsPrefs().getString(URL_KEY, START_URL);
    }

    private String getPortalName() {
        return settingsPrefs().getString(URL_NAME_KEY, "Portail AeroCampus");
    }

    private void setCurrentPortal(String name, String url) {
        settingsPrefs().edit()
            .putString(URL_KEY, url)
            .putString(URL_NAME_KEY, name)
            .apply();
    }

    private void openPortal() {
        if (webView != null) {
            status.setText("Ouverture du portail…");
            webView.loadUrl(getPortalUrl());
        }
    }

    private boolean isValidWebUrl(String value) {
        try {
            Uri uri = Uri.parse(value.trim());
            String scheme = uri.getScheme();
            return uri.getHost() != null &&
                ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) &&
                uri.getUserInfo() == null;
        } catch (Exception e) {
            return false;
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    /*
     * Appui long sur « Portail » :
     * le formulaire permet de nommer une adresse, et son bouton ☰
     * ouvre l'historique sans ajouter de bouton permanent à l'écran principal.
     */
    private void showSavePortalDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        form.setPadding(pad, dp(8), pad, 0);

        LinearLayout historyRow = new LinearLayout(this);
        historyRow.setOrientation(LinearLayout.HORIZONTAL);
        historyRow.setGravity(android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL);

        Button historyButton = new Button(this);
        historyButton.setText("☰ Historique");
        historyButton.setContentDescription("Afficher l'historique des portails");
        historyRow.addView(historyButton, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        form.addView(historyRow);

        TextView nameLabel = new TextView(this);
        nameLabel.setText("Nom à afficher");
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Ex. Wi-Fi du lycée");
        nameInput.setText(getPortalName());

        TextView urlLabel = new TextView(this);
        urlLabel.setText("Adresse du portail");
        LinearLayout.LayoutParams secondLabelParams =
            new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        secondLabelParams.topMargin = dp(10);

        EditText urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setHint("https://...");
        urlInput.setText(getPortalUrl());
        urlInput.setSelection(urlInput.getText().length());

        form.addView(nameLabel);
        form.addView(nameInput);
        form.addView(urlLabel, secondLabelParams);
        form.addView(urlInput);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Ajouter ou modifier un portail")
            .setView(form)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", null)
            .create();

        historyButton.setOnClickListener(v -> showHistoryDialog(nameInput, urlInput));

        dialog.setOnShowListener(ignored -> {
            Button saveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            saveButton.setOnClickListener(v -> {
                savePortalEntry(nameInput, urlInput, true, dialog);
            });
        });
        dialog.show();
    }

    private void savePortalEntry(EditText nameInput, EditText urlInput,
                                 boolean openAfterSave, AlertDialog dialog) {
        String name = nameInput.getText().toString().trim();
        String url = urlInput.getText().toString().trim();

        if (name.length() == 0) {
            nameInput.setError("Donne un nom à ce portail");
            return;
        }
        if (!isValidWebUrl(url)) {
            urlInput.setError("Adresse invalide. Utilise http:// ou https://");
            return;
        }

        setCurrentPortal(name, url);
        addHistoryEntry(name, url);
        // Le domaine enregistré est approuvé : plus aucune fenêtre de certificat pour lui.
        trustHostOfUrl(url);

        Toast.makeText(this, "Portail enregistré dans l'historique",
            Toast.LENGTH_SHORT).show();
        dialog.dismiss();

        if (openAfterSave) {
            openPortal();
        }
    }

    private JSONArray readHistory() {
        String raw = getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE)
            .getString(HISTORY_KEY, "[]");
        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private void addHistoryEntry(String name, String url) {
        JSONArray oldHistory = readHistory();
        JSONArray updated = new JSONArray();

        JSONObject newEntry = new JSONObject();
        try {
            newEntry.put("name", name);
            newEntry.put("url", url);
            newEntry.put("date", System.currentTimeMillis());
            updated.put(newEntry);

            for (int i = 0; i < oldHistory.length() && updated.length() < HISTORY_MAX; i++) {
                JSONObject old = oldHistory.optJSONObject(i);
                // Pas de doublon : l'ancienne entrée de la même adresse est remplacée.
                if (old != null && !url.equals(old.optString("url", ""))) updated.put(old);
            }

            getSharedPreferences(SETTINGS_NAME, MODE_PRIVATE)
                .edit().putString(HISTORY_KEY, updated.toString()).apply();
        } catch (JSONException ignored) {
            // A malformed entry is simply not added.
        }
    }

    /*
     * L'historique est accessible uniquement depuis le formulaire qui s'ouvre
     * avec un appui long sur « Portail ». Choisir une entrée remplit les champs
     * du formulaire : l'utilisateur peut ensuite modifier ou enregistrer.
     */
    private void showHistoryDialog(EditText nameInput, EditText urlInput) {
        JSONArray history = readHistory();
        if (history.length() == 0) {
            new AlertDialog.Builder(this)
                .setTitle("Historique des portails")
                .setMessage("Aucun lien enregistré pour le moment.")
                .setPositiveButton("Retour", null)
                .show();
            return;
        }

        final JSONArray entries = history;
        CharSequence[] labels = new CharSequence[entries.length()];
        SimpleDateFormat formatter =
            new SimpleDateFormat("dd/MM/yyyy à HH:mm", Locale.FRANCE);

        for (int i = 0; i < entries.length(); i++) {
            JSONObject item = entries.optJSONObject(i);
            String name = item == null ? "Portail sans nom" :
                item.optString("name", "Portail sans nom");
            long date = item == null ? 0L : item.optLong("date", 0L);
            String dateText = date > 0
                ? formatter.format(new Date(date))
                : "Date inconnue";
            String url = item == null ? "" : item.optString("url", "");
            // Nom en bleu gras, lien en vert, date en orange.
            android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
            int s1 = sb.length();
            sb.append(name);
            sb.setSpan(new android.text.style.ForegroundColorSpan(0xFF1565C0),
                s1, sb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                s1, sb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("\n");
            int s2 = sb.length();
            sb.append(url);
            sb.setSpan(new android.text.style.ForegroundColorSpan(0xFF2E7D32),
                s2, sb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append("\n");
            int s3 = sb.length();
            sb.append(dateText);
            sb.setSpan(new android.text.style.ForegroundColorSpan(0xFFE65100),
                s3, sb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            labels[i] = sb;
        }

        AlertDialog historyDialog = new AlertDialog.Builder(this)
            .setTitle("Historique des portails")
            .setItems(labels, (d, which) -> {
                JSONObject item = entries.optJSONObject(which);
                if (item == null) return;

                String name = item.optString("name", "Portail");
                String url = item.optString("url", "");
                if (!isValidWebUrl(url)) {
                    Toast.makeText(this, "Cette adresse enregistrée n'est pas valide.",
                        Toast.LENGTH_LONG).show();
                    return;
                }

                nameInput.setText(name);
                urlInput.setText(url);
                urlInput.setSelection(urlInput.getText().length());
            })
            .setNeutralButton("Effacer l'historique", (d, which) -> confirmClearHistory())
            .setNegativeButton("Retour", null)
            .create();
        historyDialog.show();
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
            .setTitle("Effacer l'historique ?")
            .setMessage("Les liens enregistrés et leurs dates seront supprimés. Le portail actuellement sélectionné restera enregistré.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Effacer", (d, which) -> {
                settingsPrefs().edit().remove(HISTORY_KEY).apply();
                Toast.makeText(this, "Historique effacé", Toast.LENGTH_SHORT).show();
            })
            .show();
    }

    private boolean isPortalHost(String host) {
        if (host == null) return false;
        Uri configured = Uri.parse(getPortalUrl());
        String configuredHost = configured.getHost();
        String lower = host.toLowerCase(Locale.US);

        if (configuredHost != null &&
            (lower.equals(configuredHost.toLowerCase(Locale.US)) ||
             lower.endsWith("." + configuredHost.toLowerCase(Locale.US)))) {
            return true;
        }
        return lower.equals("aerocampus.com") || lower.endsWith(".aerocampus.com");
    }

    private boolean shouldKeepInApp(Uri uri) {
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (host == null || scheme == null) return false;
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;
        return isPortalHost(host) || isTrustedHost(host)
            || host.equalsIgnoreCase("connectivitycheck.gstatic.com");
    }

    /* Appui long sur « Actualiser » : mémorise la page affichée et approuve son domaine. */
    private void saveCurrentPageAsValid() {
        String url = webView.getUrl();
        if (url == null || !isValidWebUrl(url)) {
            Toast.makeText(this, "Aucune page valide à enregistrer",
                Toast.LENGTH_SHORT).show();
            return;
        }
        String host = Uri.parse(url).getHost();
        String title = webView.getTitle();
        String name = (title != null && title.trim().length() > 0) ? title.trim() : host;

        addHistoryEntry(name, url);
        trustHost(host);
        Toast.makeText(this, "Page ajoutée à l'historique — domaine « " + host + " » approuvé",
            Toast.LENGTH_LONG).show();
    }

    /* Adresse ouverte depuis Android (choix de l'application à l'arrivée sur le Wi-Fi). */
    private String urlFromIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return null;
        Uri data = intent.getData();
        if (data == null) return null;
        String value = data.toString();
        return isValidWebUrl(value) ? value : null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = urlFromIntent(intent);
        if (url != null && webView != null) {
            status.setText("Ouverture du portail…");
            webView.loadUrl(url);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);

        Button back = new Button(this);
        back.setText("Retour");
        back.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
            else Toast.makeText(this, "Aucune page précédente", Toast.LENGTH_SHORT).show();
        });

        Button reload = new Button(this);
        reload.setText("Actualiser");
        reload.setOnClickListener(v -> webView.reload());
        reload.setOnLongClickListener(v -> {
            saveCurrentPageAsValid();
            return true;
        });

        Button home = new Button(this);
        home.setText("Portail");
        home.setOnClickListener(v -> openPortal());
        home.setOnLongClickListener(v -> {
            showSavePortalDialog();
            return true;
        });

        bar.addView(back, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(reload, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        bar.addView(home, new LinearLayout.LayoutParams(0,
            ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        status = new TextView(this);
        status.setText("Connexion au portail Wi-Fi…");
        status.setPadding(dp(12), dp(4), dp(12), dp(4));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setSaveFormData(true);

        webView.addJavascriptInterface(new FormStore(), "PortalStore");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress == 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onReceivedTitle(WebView view, String title) {
                if (title != null && title.length() > 0) status.setText(title);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                status.setText("Chargement du portail…");
                progress.setVisibility(View.VISIBLE);
            }

            @Override public void onPageFinished(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (isPortalHost(uri.getHost())) {
                    status.setText("Portail Wi-Fi");
                    injectFieldPersistence();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Uri uri = Uri.parse(url);
                if (shouldKeepInApp(uri)) return false;

                if ("https".equalsIgnoreCase(uri.getScheme()) ||
                    "http".equalsIgnoreCase(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        Toast.makeText(MainActivity.this,
                            "Aucune application ne peut ouvrir ce lien.",
                            Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return shouldOverrideUrlLoading(view, request.getUrl().toString());
            }

            @Override
            public void onReceivedError(WebView view, int errorCode,
                                        String description, String failingUrl) {
                if (view.getUrl() != null && view.getUrl().equals(failingUrl)) {
                    progress.setVisibility(View.GONE);
                    if (errorCode == ERROR_HOST_LOOKUP) {
                        status.setText("Adresse introuvable — connecte-toi au Wi-Fi AERO-GUESTS.");
                        Toast.makeText(MainActivity.this,
                            "Impossible de trouver le serveur. Connecte-toi d'abord au Wi-Fi du lycée, puis réessaie.",
                            Toast.LENGTH_LONG).show();
                    } else {
                        status.setText("Impossible de charger la page web.");
                    }
                }
            }

            // Certificat invalide : accepté sans fenêtre pour captiveportal.aerocampus.com et
            // pour les domaines approuvés (portail enregistré, ou page validée par appui long
            // sur « Actualiser »). Tout autre domaine déclenche une demande de confirmation.
            @Override
            public void onReceivedSslError(WebView view,
                    android.webkit.SslErrorHandler handler,
                    android.net.http.SslError error) {
                String failingUrl = error == null ? null : error.getUrl();
                String failingHost = null;
                try {
                    if (failingUrl != null) failingHost = Uri.parse(failingUrl).getHost();
                } catch (Exception ignored) { }
                if (failingHost == null && view.getUrl() != null) {
                    try { failingHost = Uri.parse(view.getUrl()).getHost(); }
                    catch (Exception ignored) { }
                }

                if (failingHost == null) {
                    handler.cancel();
                    return;
                }

                final String approvedHost = failingHost.toLowerCase(Locale.US);
                if (isTrustedHost(approvedHost) ||
                    sessionTrustedCertificateHosts.contains(approvedHost)) {
                    handler.proceed();
                    return;
                }

                String displayUrl = failingUrl == null ? approvedHost : failingUrl;
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Certificat HTTPS non valide")
                    .setMessage("Le site « " + approvedHost + " » présente un certificat que le téléphone ne peut pas vérifier.\n\n"
                        + "Continuer peut exposer les informations échangées avec ce site à une interception. Ne saisis pas de mot de passe ou d'information sensible si tu n'es pas certain de ce réseau.\n\n"
                        + "Adresse concernée : " + displayUrl + "\n\n"
                        + "Autoriser ce certificat uniquement pour ce site et pendant cette session ?\n"
                        + "(Pour l'approuver définitivement : appui long sur « Actualiser » une fois la page ouverte, ou enregistre-le via un appui long sur « Portail ».)")
                    .setNegativeButton("Refuser", (dialog, which) -> handler.cancel())
                    .setPositiveButton("Continuer", (dialog, which) -> {
                        sessionTrustedCertificateHosts.add(approvedHost);
                        handler.proceed();
                    })
                    .setOnCancelListener(dialog -> handler.cancel())
                    .show();
            }
        });

        page.addView(bar);
        page.addView(progress, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(5)));
        page.addView(status);
        page.addView(webView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(page);

        if (state != null) {
            webView.restoreState(state);
        } else {
            String fromIntent = urlFromIntent(getIntent());
            if (fromIntent != null) {
                status.setText("Ouverture du portail…");
                webView.loadUrl(fromIntent);
            } else {
                openPortal();
            }
        }
    }

    /*
     * Mémorisation locale des champs de formulaire non sensibles :
     * aucun champ de type password n'est enregistré.
     */
    private void injectFieldPersistence() {
        String js =
            "(function(){try{" +
            "var saved=JSON.parse(PortalStore.load()||'{}');" +
            "function eligible(e){" +
            " if(!e || !e.name) return false;" +
            " var t=(e.type||'').toLowerCase();" +
            " return ['text','email','tel','number','search','url'].indexOf(t)>=0 ||" +
            " e.tagName==='TEXTAREA' || e.tagName==='SELECT';" +
            "}" +
            "var els=document.querySelectorAll('input,textarea,select');" +
            "for(var i=0;i<els.length;i++){" +
            " var e=els[i]; if(!eligible(e)) continue;" +
            " var k=e.name; if(Object.prototype.hasOwnProperty.call(saved,k)) e.value=saved[k];" +
            "}" +
            "function save(){" +
            " var out={}; var a=document.querySelectorAll('input,textarea,select');" +
            " for(var j=0;j<a.length;j++){var x=a[j]; if(eligible(x)) out[x.name]=x.value;}" +
            " PortalStore.save(JSON.stringify(out));" +
            "}" +
            "document.addEventListener('input',save,true);" +
            "document.addEventListener('change',save,true);" +
            "}catch(ex){}})();";
        webView.evaluateJavascript(js, null);
    }

    private class FormStore {
        @JavascriptInterface
        public String load() {
            SharedPreferences p = getSharedPreferences("portal_fields", MODE_PRIVATE);
            return p.getString("values", "{}");
        }

        @JavascriptInterface
        public void save(String json) {
            try {
                JSONObject obj = new JSONObject(json);
                JSONObject safe = new JSONObject();
                java.util.Iterator<String> keys = obj.keys();

                while (keys.hasNext()) {
                    String key = keys.next();
                    String lower = key.toLowerCase(Locale.US);
                    if (lower.contains("pass") || lower.contains("pwd") ||
                        lower.contains("token") || lower.contains("secret")) {
                        continue;
                    }
                    Object value = obj.opt(key);
                    if (value instanceof String) safe.put(key, value);
                }

                getSharedPreferences("portal_fields", MODE_PRIVATE)
                    .edit().putString("values", safe.toString()).apply();
            } catch (JSONException ignored) {
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("PortalStore");
            webView.destroy();
        }
        super.onDestroy();
    }
}
